# SF2 Mod Menu UI Prototype v8 — safer overlay controls

This is a standalone Android floating-overlay UI prototype. It is **not** a modified Shadow Fight 2 APK and its switches do not alter game data or gameplay.

## v8 safety changes
- Overlay windows use `FLAG_NOT_TOUCH_MODAL` so touches outside the visible bubble/panel are passed to the app underneath.
- Panel is compact (up to 320 × 420 dp-equivalent pixels) and placed near the top-right instead of covering most of the screen.
- Panel title bar can be dragged to move it away from game controls.
- Bubble movement is clamped to screen bounds.
- Main activity stays available after enabling the overlay, so **STOP FLOATING MENU** remains accessible by reopening the app.
- Panel has a visible CLOSE button.

## Build
Use the included GitHub Actions workflow, or Android Studio with JDK 17, Android SDK Platform 35 and Gradle 8.7.

## Important
The bubble itself still captures touch within its small 58 × 58 area so it can be dragged or tapped. The panel captures touches only within its own visible rectangle because its buttons need interaction. Touches outside these visible windows should pass through. Test first on the home screen, not over a game match. If the overlay behaves unexpectedly, reopen this app and tap **STOP FLOATING MENU**, or revoke its **Display over other apps** permission in Android Settings.

All switches are demonstration UI controls only. They do not modify Shadow Fight 2 gameplay, memory, currencies, purchases, unlocks, or online services.
