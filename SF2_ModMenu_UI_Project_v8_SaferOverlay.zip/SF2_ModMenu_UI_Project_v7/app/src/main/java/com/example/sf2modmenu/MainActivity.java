package com.example.sf2modmenu;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private boolean waitingForOverlayPermission = false;

    @Override protected void onResume() {
        super.onResume();
        if (waitingForOverlayPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && Settings.canDrawOverlays(this)) {
            waitingForOverlayPermission = false;
            startOverlayService();
        }
    }

    private void startOverlayService() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            waitingForOverlayPermission = true;
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())));
            return;
        }
        startService(new Intent(this, OverlayService.class));
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(26, 42, 26, 26);
        root.setBackgroundColor(0xFF101010);

        TextView title = new TextView(this);
        title.setText("SHADOW FIGHT 2  |  UI PROTOTYPE");
        title.setTextColor(0xFFFF3030);
        title.setTextSize(21);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        root.addView(title);

        TextView note = new TextView(this);
        note.setText("Black & Red floating interface. Grant overlay permission, then return here; the menu starts automatically. Settings are stored locally and do not change Shadow Fight 2 gameplay or online services.");
        note.setTextColor(0xFFE0E0E0);
        note.setTextSize(14);
        note.setPadding(0, 22, 0, 22);
        root.addView(note);

        Button start = new Button(this);
        start.setText("ENABLE FLOATING MENU");
        start.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                waitingForOverlayPermission = true;
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            } else {
                startOverlayService();
            }
        });
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("STOP FLOATING MENU");
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));
        root.addView(stop);

        setContentView(root);
    }
}
