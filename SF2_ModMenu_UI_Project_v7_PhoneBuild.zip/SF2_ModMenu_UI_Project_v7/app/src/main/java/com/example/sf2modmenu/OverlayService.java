package com.example.sf2modmenu;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ToggleButton;

public class OverlayService extends Service {
    private static final String PREFS = "sf2_ui_settings";
    private static final int RED = 0xFFFF3030;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int MUTED = 0xFFBBBBBB;
    private WindowManager wm;
    private View bubble, panel;
    private WindowManager.LayoutParams bubbleParams, panelParams;
    private SharedPreferences prefs;
    private LinearLayout featureList;
    private EditText searchBox;

    private static final String[][] GROUPS = new String[][] {
        {"COMBAT", "God Mode (UI demo)", "One Hit Kill (UI demo)", "Fast Attack (UI demo)", "Freeze Enemy (UI demo)", "Custom Game Speed (UI demo)", "No Knockback (UI demo)"},
        {"PLAYER", "Infinite Stamina (UI demo)", "Fast Recovery (UI demo)", "Shadow Energy (UI demo)"},
        {"RESOURCES", "Coins Display", "Gems Display", "Energy Display", "Reward Display"},
        {"UNLOCKS", "Equipment Preview", "Weapons Preview", "Skills Preview", "Magic Preview"},
        {"SETTINGS", "FPS Counter (UI demo)", "Show Floating Button", "Compact Menu", "Remember Switches"}
    };

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        try {
            createBubble();
        } catch (RuntimeException error) {
            stopSelf();
        }
    }

    private GradientDrawable shape(int color, int radius, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        if (strokeColor != 0) d.setStroke(2, strokeColor);
        return d;
    }

    private WindowManager.LayoutParams params(int w, int h, int gravity) {
        int windowType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            w, h, windowType,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        p.gravity = gravity;
        return p;
    }

    private TextView label(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setPadding(12, 10, 12, 10);
        return t;
    }

    private void createBubble() {
        TextView b = label("SF2", 15, WHITE);
        b.setGravity(Gravity.CENTER);
        b.setTypeface(null, Typeface.BOLD);
        b.setBackground(shape(RED, 60, 0xFFFF7777));
        bubble = b;
        bubbleParams = params(58, 58, Gravity.TOP | Gravity.START);
        bubbleParams.x = prefs.getInt("bubble_x", 24);
        bubbleParams.y = prefs.getInt("bubble_y", 180);
        b.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy, ix, iy;
            boolean moved;
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    sx = (int)e.getRawX(); sy = (int)e.getRawY();
                    ix = bubbleParams.x; iy = bubbleParams.y; moved = false; return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    int dx = (int)e.getRawX() - sx, dy = (int)e.getRawY() - sy;
                    if (Math.abs(dx) > 5 || Math.abs(dy) > 5) moved = true;
                    bubbleParams.x = ix + dx; bubbleParams.y = iy + dy;
                    wm.updateViewLayout(bubble, bubbleParams); return true;
                }
                if (e.getAction() == MotionEvent.ACTION_UP) {
                    prefs.edit().putInt("bubble_x", bubbleParams.x).putInt("bubble_y", bubbleParams.y).apply();
                    if (!moved) togglePanel();
                    return true;
                }
                return true;
            }
        });
        try {
            wm.addView(bubble, bubbleParams);
        } catch (WindowManager.BadTokenException | SecurityException error) {
            bubble = null;
            stopSelf();
        }
    }

    private void togglePanel() {
        if (panel == null) showPanel();
        else removePanel();
    }

    private void removePanel() {
        if (panel != null) {
            try { wm.removeView(panel); } catch (Exception ignored) {}
            panel = null;
        }
    }

    private void addSection(String name) {
        TextView h = label(name, 13, RED);
        h.setTypeface(null, Typeface.BOLD);
        featureList.addView(h);
    }

    private void addToggle(String name) {
        ToggleButton t = new ToggleButton(this);
        t.setTextOn(name + "  ON");
        t.setTextOff(name + "  OFF");
        t.setText(name + "  OFF");
        t.setTextColor(WHITE);
        t.setTextSize(12);
        t.setAllCaps(false);
        t.setBackground(shape(0xFF292929, 12, 0xFF444444));
        t.setPadding(8, 5, 8, 5);
        t.setChecked(prefs.getBoolean(name, false));
        t.setOnCheckedChangeListener((button, checked) ->
            prefs.edit().putBoolean(name, checked).apply());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(2, 3, 2, 5);
        featureList.addView(t, lp);
    }

    private void populate(String query) {
        featureList.removeAllViews();
        String q = query == null ? "" : query.trim().toLowerCase();
        for (String[] group : GROUPS) {
            boolean headerAdded = false;
            for (int i = 1; i < group.length; i++) {
                String item = group[i];
                if (item.toLowerCase().contains(q)) {
                    if (!headerAdded) { addSection(group[0]); headerAdded = true; }
                    addToggle(item);
                }
            }
        }
        if (featureList.getChildCount() == 0) {
            TextView empty = label("No matching items", 13, MUTED);
            featureList.addView(empty);
        }
    }

    private void showPanel() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(12, 12, 12, 12);
        box.setBackground(shape(0xF0141414, 18, RED));

        TextView head = label("SHADOW FIGHT 2  •  MOD MENU", 16, RED);
        head.setTypeface(null, Typeface.BOLD);
        box.addView(head);
        TextView sub = label("LOCAL UI PROTOTYPE — NOT CONNECTED TO GAME LOGIC", 9, MUTED);
        box.addView(sub);

        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setTextSize(13);
        searchBox.setHint("Search features...");
        searchBox.setHintTextColor(MUTED);
        searchBox.setTextColor(WHITE);
        searchBox.setPadding(12, 6, 12, 6);
        searchBox.setBackground(shape(0xFF252525, 10, 0xFF555555));
        box.addView(searchBox);

        ScrollView scroll = new ScrollView(this);
        featureList = new LinearLayout(this);
        featureList.setOrientation(LinearLayout.VERTICAL);
        populate("");
        scroll.addView(featureList);
        LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(-1, 0, 1);
        scrollLp.setMargins(0, 8, 0, 8);
        box.addView(scroll, scrollLp);

        searchBox.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) { populate(s.toString()); }
            public void afterTextChanged(android.text.Editable e) {}
        });

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        TextView reset = actionButton("RESET", RED);
        reset.setOnClickListener(v -> {
            SharedPreferences.Editor editor = prefs.edit();
            for (String[] group : GROUPS) {
                for (int i = 1; i < group.length; i++) editor.remove(group[i]);
            }
            editor.apply();
            populate(searchBox.getText().toString());
        });
        TextView close = actionButton("CLOSE", 0xFF383838);
        close.setOnClickListener(v -> removePanel());
        actions.addView(reset, new LinearLayout.LayoutParams(0, -2, 1));
        actions.addView(close, new LinearLayout.LayoutParams(0, -2, 1));
        box.addView(actions);

        panel = box;
        int width = Math.min((int)(getResources().getDisplayMetrics().widthPixels * 0.88f), 420);
        int height = Math.min((int)(getResources().getDisplayMetrics().heightPixels * 0.78f), 720);
        panelParams = params(width, height, Gravity.CENTER);
        try {
            wm.addView(panel, panelParams);
        } catch (WindowManager.BadTokenException | SecurityException error) {
            panel = null;
            stopSelf();
        }
    }

    private TextView actionButton(String text, int color) {
        TextView b = label(text, 13, WHITE);
        b.setGravity(Gravity.CENTER);
        b.setTypeface(null, Typeface.BOLD);
        b.setBackground(shape(color, 10, 0));
        return b;
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }

    @Override public void onDestroy() {
        removePanel();
        if (bubble != null) {
            try { wm.removeView(bubble); } catch (Exception ignored) {}
            bubble = null;
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
