# SF2 Mod Menu UI Prototype v7

This is a standalone Android floating-overlay UI prototype. It is **not** a modified Shadow Fight 2 APK and its switches do not alter game data or gameplay.

## Included
- Draggable floating `SF2` bubble with locally saved position.
- Searchable demo switches in Combat, Player, Resources, Unlocks and Settings.
- Locally saved switch states, reset and close controls.
- Overlay permission check and responsive panel sizing.
- GitHub Actions workflow that builds a debug APK in the cloud.

## Build from a phone (no Android Studio required)
The included GitHub Actions workflow builds the APK on GitHub's cloud runner. You need a GitHub account and must upload this project to a repository.

1. Extract this ZIP on your phone.
2. In a browser, open https://github.com and sign in.
3. Create a new repository. Set its name to `sf2-modmenu-ui`; public or private is fine.
4. Open the new repository, choose **Add file → Upload files**, and upload the *contents* of this project folder (including the hidden `.github` folder). If the mobile page hides dot-folders, use GitHub's browser desktop-site mode or upload through a Git client that preserves hidden files.
5. Commit the files to `main`.
6. Open the repository's **Actions** tab. Select **Build SF2 UI Prototype APK** and tap **Run workflow** if it did not start automatically.
7. Wait for the run to finish successfully. Open the completed run, find **Artifacts**, and download `SF2-ModMenu-UI-debug`.
8. Extract the artifact ZIP and install `app-debug.apk`. Android may ask permission to install unknown apps for the browser/file manager you used.
9. Open the app, tap **ENABLE FLOATING MENU**, and grant **Display over other apps**.

## Local build requirements
- JDK 17+
- Android SDK Platform 35
- Gradle 8.7
- Android Gradle Plugin 8.6.1

## Important limitation
All switches are demonstration UI controls only. They do not change Shadow Fight 2 gameplay, IL2CPP memory, currencies, purchases, unlocks, or online services. No modified game APK is included.
